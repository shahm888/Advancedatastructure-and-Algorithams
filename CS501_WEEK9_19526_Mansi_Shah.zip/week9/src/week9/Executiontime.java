package week9;

public class Executiontime {

	public static void main(String args[]) {

		int arr2D[][] = { { 1, 3, 5, 7, 9, 3, 4, 4, 5, 6 },

				{ 1, 3, 5, 7, 9, 3, 4, 4, 5, 6 },

				{ 1, 3, 5, 7, 9, 3, 4, 4, 5, 6 },

				{ 1, 3, 5, 20, 25, 24, 33, 5, 6, 4 },

				{ 1, 3, 5, 20, 35, 24, 32, 5, 6, 4 },

				{ 1, 3, 5, 20, 28, 34, 23, 5, 6, 4 },

				{ 1, 3, 5, 21, 25, 27, 23, 5, 6, 4 },

				{ 1, 3, 5, 7, 9, 3, 4, 4, 5, 6 },

				{ 1, 3, 5, 7, 9, 3, 4, 4, 5, 6 },

				{ 1, 3, 5, 7, 9, 3, 4, 4, 5, 6 }

		};

		// Convert to 1D array.

		int arr1D[] = new int[arr2D.length * arr2D.length]; // since rows & column are same.

		for (int i = 0; i < arr2D.length; i++) {

			for (int j = 0; j < arr2D.length; j++) {

				arr1D[(i * arr2D.length) + j] = arr2D[i][j];

			}

		}

		// print(arr1D);

		long startTime = System.nanoTime();

		int cArr[] = countingSort(arr1D);

		long stopTime = System.nanoTime();

		// print(cArr);

		System.out.println("Execution time for CountingSort is : " + (stopTime - startTime) + " nano sec");

		startTime = System.nanoTime();

		int histArr[] = histogramSort(arr1D);

		stopTime = System.nanoTime();

		// print(histArr);

		System.out.println("Execution time for HistogramSort is : " + (stopTime - startTime) + " nano sec");

	}

	private static int[] histogramSort(int[] arr) {

		int n = arr.length;

		int output[] = new int[n];

		int counter = 0;

		int count[] = new int[256];

		for (int i = 0; i < 256; ++i)

			count[i] = 0;

		for (int i = 0; i < arr.length; ++i)

			++count[arr[i]];

		for (int i = 0; i < 256; ++i) {

			if (count[i] > 0) {

				int num = count[i];

				while (num > 0) {

					output[counter++] = i;

					num--;

				}

			}

		}

		return output;

	}

	private static void print(int[] arr) {

		for (int i = 1; i <= arr.length; i++) {

			System.out.print(arr[i - 1] + " ");

			if (i % 10 == 0) {

				System.out.println();

			}

		}

	}

	private static int[] countingSort(int[] arr) {

		int n = arr.length;

		int output[] = new int[n];

		int count[] = new int[256];

		for (int i = 0; i < 256; ++i)

			count[i] = 0;

		for (int i = 0; i < arr.length; ++i)

			++count[arr[i]];

		// Change count[i] so that count[i] now contains actual

		// position of this character in output array

		for (int i = 1; i <= 255; ++i)

			count[i] += count[i - 1];

		// Build the output character array

		// To make it stable we are operating in reverse order.

		for (int i = n - 1; i >= 0; i--)

		{

			output[count[arr[i]] - 1] = arr[i];

			--count[arr[i]];

		}

		return output;

	}

}
