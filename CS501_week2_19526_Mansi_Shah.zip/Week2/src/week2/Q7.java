package week2;

import java.util.Scanner;

public class Q7 {
	public static void main(String args[]) {
		int a, b, c;
		int median;
		System.out.print("Enter 3 integers:");
		Scanner reader = new Scanner(System.in);
		a = reader.nextInt();
		b = reader.nextInt();
		c = reader.nextInt();
		reader.close();

		if ((a > b && b > c) || (c > b && b > a)) {
			median = b;
		} else if ((b < a && a < c) || (c < a && a < b)) {
			median = a;
		} else {
			median = c;
		}

		System.out.println("Median is : " + median);
		
		
	}
}


