package week2;

import java.util.Scanner;

public class Q46 {
	public static void main(String args[]) {
		int row, column;
		int count = -1;
		int noOfRows = 0;
		
		System.out.print("Enter number of rows:");
		Scanner reader = new Scanner(System.in);
		noOfRows = reader.nextInt();
		reader.close();

		for (row = 0; row < noOfRows; row++) {

			for (column = 0; column <= row; column++) {
				count = count + 1;
				System.out.print(count + " ");
			}
			System.out.println();
		}
	}
}
